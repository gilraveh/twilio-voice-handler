Deno.serve(async (req) => {
  const xmlResponse = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="alice" language="he-IL">שלום, זו בדיקת שיחה מהמערכת</Say>
</Response>`;

  return new Response(xmlResponse.trim(), {
    status: 200,
    headers: {
      "Content-Type": "application/xml"
    }
  });
});
